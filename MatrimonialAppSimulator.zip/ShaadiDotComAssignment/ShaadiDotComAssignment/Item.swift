//
//  Item.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

import Foundation
import SwiftData

@Model
final class Item {
    var timestamp: Date
    var title: String?
    var uniqueId: String?
    var address: String?
    var gender: Gender?
    var userImageUrl: String?
    var didTakeAction: Bool? = nil
    var age: String?

    init(timestamp: Date) {
        self.timestamp = timestamp
    }
}
