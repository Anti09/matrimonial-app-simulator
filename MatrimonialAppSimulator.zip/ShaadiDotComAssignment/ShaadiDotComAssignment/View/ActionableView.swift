//
//  ActionableView.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 24/12/24.
//

import SwiftData
import SwiftUI


struct ActionableView: View {
    @Environment(\.modelContext) private var modelContext
    @State private var accept: Bool? = nil
    @State private var isAnimatedViewAppear: Bool = false
    let info: UserInfoDataModel
    var body: some View {
        GeometryReader { geo in
            if accept == nil &&
                hasAlreadyTakeAction == nil  {
                HStack {
                    Spacer()

                    Button {
                        accept = false
                        isAnimatedViewAppear = true
                        addItem(userModel: info, didTakeAction: accept)
                    } label: {
                        TakeActionableView(type: .decline, isSelected: accept == false)
                    }

                    Spacer()

                    Button {
                        accept = true
                        isAnimatedViewAppear = true
                        addItem(userModel: info, didTakeAction: accept)
                    } label: {
                        TakeActionableView(type: .accept, isSelected: accept == true)
                    }

                    Spacer()
                }
            }
            
            if let accept {
                AnimatedView(
                    height: 80,
                    width: geo.size.width * 0.8,
                    text: accept ? "Accepted" : "Declined"
                )
                .position(x: geo.frame(in: .local).midX, y: geo.frame(in: .local).midY)
            } else {
                if let hasAlreadyTakeAction {
                    AnimatedView(
                        height: 80,
                        width: geo.size.width * 0.8,
                        text: hasAlreadyTakeAction ? "Accepted" : "Declined"
                    )
                    .position(x: geo.frame(in: .local).midX, y: geo.frame(in: .local).midY)
                }
            }
        }
    }

    private var hasAlreadyTakeAction: Bool? {
        let fetchRequest = FetchDescriptor<Item>()
        do {
            let users = try modelContext.fetch(fetchRequest)
            if users.contains(where: { $0.uniqueId ?? "" == info.id }) {
                if let didTakeAction = users.first(where: { $0.uniqueId ?? "" == info.id })?.didTakeAction {
                    return didTakeAction
                }
            }
        } catch {
            print("No Action Taken")
        }
        return nil
    }

    private func addItem(userModel: UserInfoDataModel, didTakeAction: Bool? = nil) {

        // checking if there is any existing record
        let fetchRequest = FetchDescriptor<Item>()
        do {
            let users = try modelContext.fetch(fetchRequest)
            users.forEach {
                if $0.uniqueId == userModel.id {
                    $0.didTakeAction = didTakeAction
                    modelContext.insert($0)
                    return
                }
            }
        } catch {
            print(error.localizedDescription)
        }
    }
}
