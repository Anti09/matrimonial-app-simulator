//
//  TitleView.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 24/12/24.
//

import SwiftUI

struct TitleView: View {
    var userDetails: UserInfoDataModel
    var body: some View {
        Text(userDetails.name)
            .font(.largeTitle)
            .foregroundColor(.teal)
            .bold()
        Text(userDetails.location)
            .font(.subheadline)
            .foregroundColor(.gray)
            .bold()
            .multilineTextAlignment(.center)
    }
}
