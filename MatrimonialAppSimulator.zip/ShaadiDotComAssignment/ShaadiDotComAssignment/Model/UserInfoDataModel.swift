//
//  UserInfoDataModel.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

struct UserInfoDataModel: Identifiable, Hashable {
    var id: String
    let gender: Gender
    let name: String
    let location: String
    let userImageUrl: String
    let age: String
    
    static func == (lhs: UserInfoDataModel, rhs: UserInfoDataModel) -> Bool {
        lhs.id == rhs.id
    }
}

enum ActionType: String {
    case accept = "checkmark"
    case decline = "multiply"
}

