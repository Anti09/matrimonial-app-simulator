//
//  UserInfoModel.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

import Combine
import Foundation
import SwiftData
import SwiftUI

class UserInfoViewModel: ObservableObject {

    private var cancellable = Set<AnyCancellable>()
    @Published var userInfoDataModel: [UserInfoDataModel] = []
    private var apiWorker: ApiWorkerProtocol
    @Published var isLoading: Bool = true
    @Published var isDataAvailable: Bool = true

    init(worker: ApiWorkerProtocol) {
        apiWorker = worker
    }

    func getUserInformation()  {
        apiWorker.fetchUserInfo()
            .sink { errorCompletion in
                switch errorCompletion {
                case .finished:
                    print("Finished")
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        self.isLoading = false
                    }
                case .failure(let error):
                    print(error)
                }
            } receiveValue: { [weak self] responseModel in
                guard let self else { return }
                userInfoDataModel = generateDataModel(usersInfo: responseModel.results)
            }
            .store(in: &cancellable)
    }

    private func generateDataModel(usersInfo: [UserInfoModel]) -> [UserInfoDataModel] {
        var dataModel: [UserInfoDataModel] = []
        usersInfo.forEach { info in
            dataModel.append(UserInfoDataModel(id: info.id.value ?? "123456789", gender: info.gender, name: info.fullName, location: info.fullAddress, userImageUrl: info.picture.large, age: "\(info.dob.age)", state: .pending))
        }
        return dataModel.sorted { $0.name < $1.name }
    }

    func generateDataModel(users: [Item]) {
        userInfoDataModel.removeAll()
        if !users.isEmpty {
            users.sorted { $0.title ?? "" < $1.title ?? "" }.forEach { user in
                userInfoDataModel.append(UserInfoDataModel(id: user.uniqueId ?? "123456789", gender: user.gender ?? .male, name: user.title ?? "Unknown", location: user.address ?? "Unknown", userImageUrl: user.userImageUrl ?? "", age: user.age ?? "-1", state: user.state ?? .pending))
            }
        } else {
            isDataAvailable = false
        }
        DispatchQueue.main.async {
            self.isLoading = false
        }
    }
}
