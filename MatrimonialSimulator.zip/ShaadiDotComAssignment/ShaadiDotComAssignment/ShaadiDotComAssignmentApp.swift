//
//  ShaadiDotComAssignmentApp.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

import SwiftUI
import SwiftData

@main
struct ShaadiDotComAssignmentApp: App {
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            Item.self,
        ])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)

        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()

    init() {
        Reachability.shared.checkInternetConnection()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(sharedModelContainer)
    }
}
