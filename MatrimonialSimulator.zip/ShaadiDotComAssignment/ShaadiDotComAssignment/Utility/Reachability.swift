//
//  Reachability.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

import Network

class Reachability {
    static let shared = Reachability()
    var isConnected = false
    private init() {}
    

    func checkInternetConnection() {
        let monitor = NWPathMonitor()
        monitor.pathUpdateHandler = { path in
            self.isConnected = (path.status == .satisfied)
        }
        let queue = DispatchQueue(label: "InternetMonitor")
        monitor.start(queue: queue)
    }
}
