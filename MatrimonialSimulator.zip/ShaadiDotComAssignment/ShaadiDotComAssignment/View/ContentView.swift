//
//  ContentView.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

import SwiftUI
import SwiftData

struct ContentView: View {

    @Environment(\.modelContext) private var modelContext
    @ObservedObject var viewModel: UserInfoViewModel
    @State private var showAlert = false

    init() {
        viewModel = UserInfoViewModel(worker: APIWorker())
    }

    var body: some View {
        ScrollView {
            if viewModel.isLoading {
                ProgressView("Loading...")
                    .progressViewStyle(.circular)
            } else if !viewModel.isDataAvailable {
                VStack {
                }
                .alert("Seems Like there is no data or Internet is Missing", isPresented: $showAlert) {
                    Button("OK", role: .cancel) {}
                }
                .onAppear {
                    if viewModel.userInfoDataModel.isEmpty {
                        showAlert = true
                    }
                }
            }
            else {
                ForEach(viewModel.userInfoDataModel) { model in
                    UserInfoView(userInfo: model)
                        .frame(width: UIScreen.main.bounds.width - 32, height: UIScreen.main.bounds.width, alignment: .center)
                        .onAppear {
                            addItem(userModel: model)
                        }
                }
            }
        }
        .onAppear {
            existingUsersHandling()
        }
    }

    private func existingUsersHandling() {
        guard Reachability.shared.isConnected
        else {
            existingUser()
            viewModel.isLoading = false
            return
        }

        if checkForLocalData {
            existingUser()
        } else if viewModel.userInfoDataModel.isEmpty {
            viewModel.getUserInformation()
        } else {
            existingUser()
        }
    }

    private var checkForLocalData: Bool {
        do {
            return try !modelContext.fetch(FetchDescriptor<Item>()).isEmpty
        } catch {
            return false
        }
    }

    private func existingUser() {
        let fetchRequest = FetchDescriptor<Item>()
        do {
            let users = try modelContext.fetch(fetchRequest)
            viewModel.generateDataModel(users: users)
        } catch {
            print("No Internet Connection")
        }
    }

    private func addItem(userModel: UserInfoDataModel) {

        // checking if there is any existing record
        do {
            let users = try modelContext.fetch(FetchDescriptor<Item>())
            if !users.contains(where: {$0.uniqueId ?? "" == userModel.id }) {
                let item = Item(timestamp: Date())
                item.address = userModel.location
                item.uniqueId = userModel.id
                item.title = userModel.name
                item.age = userModel.age
                item.gender = userModel.gender
                item.userImageUrl = userModel.userImageUrl
                modelContext.insert(item)
            }
        } catch {
            print("Duplicate")
        }
    }
}

#Preview {
    ContentView()
        .modelContainer(for: Item.self, inMemory: true)
}
