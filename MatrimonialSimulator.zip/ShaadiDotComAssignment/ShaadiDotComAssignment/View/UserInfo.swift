//
//  UserInfo.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

import SwiftUI
import SwiftData

struct UserInfoView: View {
    @Environment(\.modelContext) private var modelContext
    var userInfo: UserInfoDataModel
    @State var didTapOnDetails: Bool = false
    @State var isProfileAccepted: Bool = false
    var body: some View {
        ZStack {
            VStack {
                ImageView(info: userInfo)
                    .padding(.top, 8)
                Spacer()
                TitleView(userDetails: userInfo)
                Spacer()
                ActionableView(isProfileAccepted: $isProfileAccepted, info: userInfo)
            }
            .frame(width: UIScreen.main.bounds.width - 50, height: UIScreen.main.bounds.width, alignment: .center)
            .background(.white)
            .cornerRadius(25)
        }
        .onTapGesture(count: 2) {
            didTapOnDetails = true
        }
        .shadow(color: .black.opacity(0.2), radius: 5)
        .fullScreenCover(isPresented: $didTapOnDetails) {
            DetailedDescriptionView(userDetail: userInfo)
                .background(BackgroundClearView())
        }
        .onChange(of: isProfileAccepted, { oldValue, newValue in
            if newValue {
                didTapOnDetails = true
            }
        })
    }
}

#Preview {
    UserInfoView(userInfo: UserInfoDataModel(id: "123456789", gender: .male, name: "Hello World", location: "25, baker street\n CA, USA", userImageUrl: "https://randomuser.me/api/portraits/women/17.jpg", age: "27"))
}
