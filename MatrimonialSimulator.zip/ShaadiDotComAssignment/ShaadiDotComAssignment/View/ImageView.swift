//
//  ImageView.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 24/12/24.
//

import SwiftUI

struct ImageView: View {
    let info: UserInfoDataModel
    var height: CGFloat = 160
    var width: CGFloat = 160
    var radius: CGFloat = 80
    var body: some View {
        AsyncImage(url: URL(string: info.userImageUrl),
                   transaction: Transaction( animation: .spring(response: 1, dampingFraction: 0.65, blendDuration: 0.025))
        ) { phase in
            switch phase {
            case .success(let image):
                image
                    .resizable()
                    .scaledToFit()
                    .frame(width: width, height: height)
                    .cornerRadius(radius)
            case .failure(_):
                Image(info.gender == .female ? .femaleImagePlaceHolder : .maleImagePlaceHolder)
                    .resizable()
                    .scaledToFit()
                    .frame(width: width, height: height)
                    .opacity(0.6)
            case .empty:
                Image(systemName: "photo.circle.fill")
                    .foregroundColor(.teal)
                    .opacity(0.6)
            default:
                ProgressView()
            }
        }
    }
}

#Preview {
    ImageView(info: Utility.utilityUserInfoDataModel)
}
