//
//  SelectedActionableView.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

import SwiftUI

struct AnimatedView: View {
    @State private var isVisible: Bool = false
    var height, width: CGFloat
    var text: String

    var body: some View {
        ZStack {
            Spacer()
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.teal)
                .frame(width: width, height: height)
                .opacity(isVisible ? 1 : 0)
                .animation(.easeIn(duration: 2), value: isVisible)
                .onAppear {
                    isVisible = true
                }
            Text(text)
                .opacity(isVisible ? 1 : 0)
                .animation(.easeIn(duration: 2), value: isVisible)
                .foregroundColor(.white)
                .bold()
                .font(.title2)
                .fontDesign(.rounded)
            Spacer()
        }
    }
}

#Preview() { AnimatedView(height: 80, width: UIScreen.main.bounds.width - 32, text: "Declined") }
