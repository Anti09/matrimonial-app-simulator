//
//  DetailedView.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal Mac  on 24/12/24.
//

import SwiftUI

struct DetailedDescriptionView: View {
    @Environment(\.dismiss) var dismiss
    let userDetail: UserInfoDataModel
    var body: some View {
        RoundedRectangle(cornerRadius: 50)
            .overlay {
                VStack {
                    VStack {
                        HStack {
                            Spacer()
                            Button {
                                dismiss()
                            } label: {
                                Image(systemName: "multiply")
                            }
                        }
                        .padding([.trailing, .top], 10)
                        .foregroundColor(.white)
                        Text("Insider Details")
                            .customTextModifier(foregroundColor: .black, font: .title2, fontDesign: .monospaced, align: .center)
                            .shadow(color: .white, radius: 5)
                            .lineLimit(5)
                            .padding(.top, -20)
                    }
                    .padding(.top, -20)

                    VStack(alignment: .leading) {
                        Text("Name : \(userDetail.name)")
                            .customTextModifier(foregroundColor: .black, font: .title3, fontDesign: .serif)
                            .shadow(color: .white, radius: 5)

                        Text("Age : \(userDetail.age) \nGender : \(userDetail.gender.rawValue)")
                            .customTextModifier(foregroundColor: .black, font: .title3, fontDesign: .serif)
                            .shadow(color: .white, radius: 5)

                        Text("Address : \(userDetail.location)")
                            .customTextModifier(foregroundColor: .black, font: .title3, fontDesign: .serif)
                            .shadow(color: .white, radius: 5)
                    }

                    Text("Thanks for checking")
                        .customTextModifier(foregroundColor: .teal, font: .title2, fontDesign: .monospaced)
                        .shadow(color: .black, radius: 5)
                }
            }
            .shadow(radius: 10)
            .padding(30)
            .frame(width: 350, height: 400)
            .foregroundColor(.white.opacity(0.3))
            .background(ImageView(info: userDetail, height: 300, width: 300, radius: 150))
    }
}

struct TextModifier: ViewModifier {
    let foregroundColor: Color
    let font: Font
    let fontDesign: Font.Design
    let align: TextAlignment

    func body(content: Content) -> some View {
        content
            .font(font)
            .bold()
            .fontDesign(fontDesign)
            .foregroundColor(foregroundColor)
            .multilineTextAlignment(align)
    }
}

extension View {
    func customTextModifier(foregroundColor: Color, font: Font, fontDesign: Font.Design, align: TextAlignment = .leading) -> some View {
        modifier(TextModifier(foregroundColor: foregroundColor, font: font, fontDesign: fontDesign, align: align))
    }
}

