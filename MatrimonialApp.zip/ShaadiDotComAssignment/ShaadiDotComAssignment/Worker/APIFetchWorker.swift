//
//  APIFetchWorker.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//


import Combine
import Foundation

protocol ApiWorkerProtocol: AnyObject {
    func fetchUserInfo() -> Future<UsersResponseModel, Error>
}

class APIWorker: ApiWorkerProtocol {

    private var cancellable = Set<AnyCancellable>()

    func fetchUserInfo() -> Future<UsersResponseModel, Error> {

        return Future<UsersResponseModel, Error> { [weak self] promise in

            guard let self,
                  let url = URL(string: Utility.url)
            else {
                return promise(.failure(APIError.invalidURL))
            }
            
            URLSession.shared.dataTaskPublisher(for: url)
                .tryMap { (data, response) -> Data in
                    guard let httpResponse = response as? HTTPURLResponse,
                          200...299 ~= httpResponse.statusCode
                    else {
                        throw APIError.responseError
                    }
                    return data
                }
                .tryMap { data in
                    do {
                        let apiResponse = try JSONDecoder().decode(UsersResponseModel.self, from: data)
                        return apiResponse
                    } catch {
                        print("Error decoding JSON: \(error)")
                        throw error
                    }
                }
                .receive(on: RunLoop.main)
                .sink { completion in
                    if case let .failure(error) = completion {
                        switch error {
                        case let decodingError as DecodingError:
                            promise(.failure(decodingError))
                        case let apiError as APIError:
                            promise(.failure(apiError))
                        default:
                            promise(.failure(APIError.unknown))
                        }
                    }
                } receiveValue: { response in
                    promise(.success(response))
                }
                .store(in: &self.cancellable)
        }
    }
    
}

enum APIError: Error {
    case invalidURL
    case responseError
    case unknown
}
