//
//  UserInfoModel.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

// MARK: - Welcome
struct UsersResponseModel: Codable {
    let results: [UserInfoModel]
}

// MARK: - Result
struct UserInfoModel: Codable {
    let gender: Gender
    let name: Name
    let location: Location
    let email: String
    let dob, registered: Dob
    let phone, cell: String
    let id: ID
    let picture: Picture

    var fullName: String {
        name.title.rawValue + ". " + name.first + " " + name.last
    }

    var cityCountry: String {
        location.city + ", " + location.state
    }

    var street: String {
        "\(location.street.number)" + " " + location.street.name
    }

    var fullAddress: String {
        "\(street)\n\(cityCountry)"
    }
}

// MARK: - Dob
struct Dob: Codable {
    let date: String
    let age: Int
}

enum Gender: String, Codable {
    case female = "female"
    case male = "male"
}

// MARK: - ID
struct ID: Codable {
    let name: String
    let value: String?
}

// MARK: - Location
struct Location: Codable {
    let street: Street
    let city, state, country: String
}

// MARK: - Street
struct Street: Codable {
    let number: Int
    let name: String
}

struct Name: Codable {
    let title: Title
    let first, last: String
}

enum Title: String, Codable {
    case monsieur = "Monsieur"
    case mr = "Mr"
    case mrs = "Mrs"
    case miss = "Miss"
    case ms = "Ms"
    case unknown

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        let rawValue = try container.decode(String.self)
        self = Title(rawValue: rawValue) ?? .unknown
    }
}


// MARK: - Picture
struct Picture: Codable {
    let large, medium, thumbnail: String
}
