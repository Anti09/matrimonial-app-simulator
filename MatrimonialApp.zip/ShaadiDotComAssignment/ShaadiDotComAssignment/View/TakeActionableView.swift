//
//  TakeActionableView.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 24/12/24.
//

import SwiftUI

struct TakeActionableView: View {
    var type: ActionType
    var isSelected: Bool
    var body: some View {
        Circle()
            .fill(.white)
            .shadow(color: .teal, radius: 1)
            .frame(width: 80, height: 80)
            .padding(.bottom, 15)
            .overlay {
                Image(systemName: type.rawValue)
                    .resizable()
                    .frame(width: 30, height: 30, alignment: .center)
                    .padding(.bottom, 10)
                    .foregroundColor(.gray)
            }
    }
}
