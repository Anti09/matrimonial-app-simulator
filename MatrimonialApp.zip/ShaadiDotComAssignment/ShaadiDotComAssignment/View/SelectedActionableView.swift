//
//  SelectedActionableView.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

import SwiftUI

struct AnimatedView: View {
    @State private var isVisible: Bool = false
    var height, width: CGFloat
    var type: ActionType

    var body: some View {
        ZStack {
            Spacer()
            RoundedRectangle(cornerRadius: 10)
                .fill(
                    type == .accept ? Color(hex: "#A3D9A5") : Color(hex: "#FF6347")
                )
                .frame(width: width, height: height)
                .opacity(isVisible ? 1 : 0)
                .animation(.easeIn(duration: 2), value: isVisible)
                .onAppear {
                    isVisible = true
                }
            Text(type == .accept ? Utility.accepted : Utility.declined)
                .opacity(isVisible ? 1 : 0)
                .animation(.easeIn(duration: 2), value: isVisible)
                .foregroundColor(.white)
                .bold()
                .font(.title2)
                .fontDesign(.rounded)
            Spacer()
        }
    }
}

#Preview() { AnimatedView(height: 80, width: UIScreen.main.bounds.width - 32, type: .decline) }
