//
//  UserInfo.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 23/12/24.
//

import SwiftUI
import SwiftData

struct UserInfoView: View {
    @Environment(\.modelContext) private var modelContext
    var userInfo: UserInfoDataModel
    @State var didTapOnDetails: Bool = false
    @State var selectionState: ProfileSelectionState = .pending
    @State var didStateChange: Bool? = nil
    var colors: [Color] {
        if let didStateChange {
            return didStateChange ? [Color(hex: "#A3D9A5"), Color(hex: "#A3D9A5").opacity(0.1), .white] : [Color(hex: "#FF6347"), Color(hex: "#FF6347").opacity(0.1), .white]
        }
        return [.teal, .teal.opacity(0.1), .white]
    }
    var body: some View {
        ZStack {
            VStack {
                ImageView(info: userInfo)
                    .padding(.top, 8)
                Spacer()
                TitleView(userDetails: userInfo, selectionState: $selectionState)
                Spacer()
                ActionableView(selectionState: $selectionState, info: userInfo)
            }
            .frame(width: UIScreen.main.bounds.width - 50, height: UIScreen.main.bounds.width, alignment: .center)
            .background(
                LinearGradient(colors: colors, startPoint: .top, endPoint: .bottom)
            )
            .cornerRadius(25)
        }
        .onTapGesture(count: 2) {
            didTapOnDetails = true
        }
        .shadow(color: .black.opacity(0.2), radius: 3, x: 1, y: 0)
        .fullScreenCover(isPresented: $didTapOnDetails) {
            DetailedDescriptionView(userDetail: userInfo, state: selectionState)
                .background(BackgroundClearView())
        }
        .onChange(of: selectionState) { oldValue, newValue in
            selectionState = newValue
            switch newValue {
            case .accepted:
//                didTapOnDetails = true
                didStateChange = true
            case .declined:
                didStateChange = false
            default:
                break
            }
        }
        .onAppear {
            if let previousState {
                didStateChange = userInfo.state == .accepted ? true : false
            }
        }
    }

    private var previousState: ProfileSelectionState? {
        let fetchRequest = FetchDescriptor<Item>()
        do {
            let users = try modelContext.fetch(fetchRequest)
            if users.contains(where: { $0.uniqueId ?? "" == userInfo.id }) {
                if let state = users.first(where: { $0.uniqueId ?? "" == userInfo.id })?.state {
                    return state
                }
            }
        } catch {
            print("")
        }
        return nil
    }
}

#Preview {
    UserInfoView(userInfo: Utility.utilityUserInfoDataModel)
}
