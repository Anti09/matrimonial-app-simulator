//
//  TitleView.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 24/12/24.
//

import SwiftUI
import SwiftData

struct TitleView: View {
    var userDetails: UserInfoDataModel
    @Environment(\.modelContext) private var modelContext
    @Binding var selectionState: ProfileSelectionState
    var body: some View {
        Text(userDetails.name)
            .font(.title2)
            .foregroundColor(selectionState == .pending ? .teal : (selectionState == .accepted ? Color(hex: "#A3D9A5") : Color(hex: "#FF6347")))
            .bold()
            .shadow(color: .white, radius: 5, x: 1, y: 1)
        Text(userDetails.location)
            .font(.subheadline)
            .foregroundColor(.gray)
            .bold()
            .multilineTextAlignment(.center)
            .shadow(color: .white, radius: 5, x: 1, y: 1)
            .onAppear {
                if let previousState {
                    selectionState = previousState
                }
            }
    }

    private var previousState: ProfileSelectionState? {
        let fetchRequest = FetchDescriptor<Item>()
        do {
            let users = try modelContext.fetch(fetchRequest)
            if users.contains(where: { $0.uniqueId ?? "" == userDetails.id }) {
                if let state = users.first(where: { $0.uniqueId ?? "" == userDetails.id })?.state {
                    return state
                }
            }
        } catch {
            print("")
        }
        return nil
    }
}
