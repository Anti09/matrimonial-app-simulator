//
//  BackgroundClearView.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 24/12/24.
//

import SwiftUI

struct BackgroundClearView: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        DispatchQueue.main.async {
            view.superview?.superview?.backgroundColor = .black.withAlphaComponent(0.7)
        }
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {}
}
