//
//  Utility+String.swift
//  ShaadiDotComAssignment
//
//  Created by Pranjal  on 24/12/24.
//

final class Utility {
    static let url = "https://randomuser.me/api/?results=10"
    static let errorMessage = ""
    static let noUserFound = "No User Found"
    static let duplicateItem = "Duplicate Item"
    static let noAction = "No Action Taken"
    static let accepted = "Accepted"
    static let declined = "Declined"

    static var utilityUserInfoDataModel: UserInfoDataModel {
        UserInfoDataModel(
            id: "123456789",
            gender: .male,
            name: "Hello World",
            location: "25, baker street\n CA, USA",
            userImageUrl: "https://randomuser.me/api/portraits/women/17.jpg",
            age: "25", state: .pending
        )
    }

    static let navigationTitle = "Profile Matches"
    static let loadingText = "Loading..."
    static let alert = "Alert"
    static let ok = "OK"

}
